These folders contain the evaluation data. The dropped out data components have been replaced with NaN according to the difficulty level.

Each folder includes the reference data, named ref.mat. This is the same dataset for each difficulty level, but with dropped out values replaced by NaN.